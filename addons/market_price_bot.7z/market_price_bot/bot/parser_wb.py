def parse_wb(url: str):
    return "Wildberries product", 0
